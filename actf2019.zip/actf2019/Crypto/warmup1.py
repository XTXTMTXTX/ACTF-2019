import os

real_flag = 'ACTF{...}'
fake_flag = 'ACTF{033d4a884dc9389028295ad21617d467071a9845497ce05c}'

def xor(a, b):
	return ''.join(chr(ord(x) ^ ord(y)) for (x, y) in zip(a, b))

def single_round(m, k):
	assert len(m) == 48
	l = m[: 24]
	r = m[24: ]
	nl, nr = r, xor(k, xor(l, r))
	return nl + nr

def encrypt(m, k):
	for i in k:
		m = single_round(m, i)
	return m

k = []
for i in range(0, 10):
	k.append(os.urandom(24))
print encrypt(fake_flag[5: -1], k).encode('hex')
print encrypt(real_flag[5: -1], k).encode('hex')
#6f5f5e16d6903a2ad25a67040047bbebd5bcd3f541376852c5380349aa281d1f8bbcd8977a04a88fd4641cb1ac2162e7
#3b001c55d7c8535e8b1d3e004b03eae7d0e787f0403e6a50d331071dfa75133883e691f56a19b6d6bc7416ecf1275b91
