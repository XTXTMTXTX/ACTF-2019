#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
from Crypto.Cipher import AES

KEY = os.urandom(16)
SECRET = os.urandom(19)
FLAG1 = 'ACTF{...}'

def pad(msg):
    return msg + chr(16 - len(msg) % 16) * (16 - len(msg) % 16)

def encrypt(msg):
    cipher = AES.new(KEY, AES.MODE_ECB)
    return cipher.encrypt(pad(msg))

def welcome():
    return encrypt('Welcome to ACTF-2019, hope you enjoy this challenge :)').encode('hex')

def get_secret():
    name = raw_input('Your name: ').decode('hex')
    assert len(name) <= 48
    return encrypt('Your name:' + name + 'Your secret:' + SECRET).encode('hex')

def get_flag():
    guess = raw_input('Tell me your answer: ').strip().decode('hex')
    return guess == SECRET

print '''
  _                    _                  ______  _____ 
 | |                  | |           /\   |  ____|/ ____|
 | |     _____   _____| |_   _     /  \  | |__  | (___  
 | |    / _ \ \ / / _ | | | | |   / /\ \ |  __|  \___ \ 
 | |___| (_) \ V |  __| | |_| |  / ____ \| |____ ____) |
 |______\___/ \_/ \___|_|\__, | /_/    \_|______|_____/ 
                          __/ |                         
                         |___/                          

'''

print welcome()

for i in xrange(0xAAA):
    try:
        msg = raw_input('Your option: ').decode('hex')
        assert len(msg) <= 320
        if msg.startswith('Get secret'):
            print get_secret()
        elif msg.startswith('Get flag'):
            if get_flag():
                print 'All right. Here is your flag: %s' % FLAG1
            else:
                print 'No No No...'
                exit(0)
        elif msg.startswith('Exit'):
            print 'Bye~'
            exit(0)
        else:
            print 'No such option...'
    except:
        exit(0)
