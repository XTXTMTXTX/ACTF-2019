
mask = 0x8bc3210d00331741833ca3c4af14f82293653df561b4b55a5a41
limit = 0xffffffffffffffffffffffffffffffffffffffffffffffffffff

def LFSR(input):
	output = (input << 1) & limit
	i = (input & mask) & limit
	lsb = 0
	while i != 0:
		lsb ^= (i & 1)
		i = i >> 1
	output ^= lsb
	return (output, lsb)

flag = 'ACTF{...}'
assert len(flag) == 32
R = int(flag[5: -1].encode('hex'), 16)

tmp = 0
for i in range(208):
	(R, lsb) = LFSR(R)
	tmp = (tmp << 1) | lsb
print hex(tmp)
#0x3a7c0143e3e26d1425b5c3d2d2ae4041de5e22f6557836bdae6fL
